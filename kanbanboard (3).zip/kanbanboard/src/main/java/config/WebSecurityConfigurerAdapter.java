package config;

import org.springframework.security.authentication.AuthenticationManager;

public class WebSecurityConfigurerAdapter {
    protected AuthenticationManager authenticationManagerBean() {

    }
}
