package model;

public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    DONE
}
