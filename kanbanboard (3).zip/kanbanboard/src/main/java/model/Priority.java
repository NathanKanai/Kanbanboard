package model;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}
