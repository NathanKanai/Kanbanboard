package repository;

public class User {

}
